package kr.co.springprac.Eat_go;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EatGoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EatGoApplication.class, args);
	}

}
