package kr.co.springprac.Eat_go;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EatGoApplicationTests {

	@Test
	void contextLoads() {
	}

}
